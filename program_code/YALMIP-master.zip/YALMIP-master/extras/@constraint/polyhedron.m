function P = polyhedron(C)
%POLYHEDRON (Overloaded)

P = Polyhedron(lmi(C));
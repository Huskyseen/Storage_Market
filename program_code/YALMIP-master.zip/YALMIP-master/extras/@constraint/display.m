function display(X)

display(lmi(X));

function cx = getcx(X)

cx = X.cx;

function X = unfactor(X)
X.leftfactors = [];
X.midfactors = [];
X.rightfactors = [];